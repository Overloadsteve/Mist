package com.overloadsteve.mist

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var iconImageView: ImageView
    private val loadingDuration = 3000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        iconImageView = findViewById(R.id.pork)

        loadingScreen()
    }

    private fun loadingScreen() {
        Handler().postDelayed({
            val intent = Intent(this, ODActivity::class.java)
            startActivity(intent)
            finish()
        }, loadingDuration)
    }
}